const { GraphQLClient  } = require('graphql-request')

const client = new GraphQLClient('https://api.graph.cool/simple/v1/cjcgfcs363v5p0110vjauvz03')

const query = `{
  allModels {
    id
    article
    name
  }
}`

exports.handler = (event, context, callback) => {
    console.log("Received event {}", JSON.stringify(event, 3))
    client.request(query).then(data => callback(null, data))
}
